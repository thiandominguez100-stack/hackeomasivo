export const SIMULATION_TOTAL = 3_000_000;
export const DEFAULT_RATE = 25_000;

export const LOCATIONS = Object.freeze([
  { city: 'Buenos Aires', country: 'AR', region: 'Sudamérica', lat: -34.6037, lon: -58.3816 },
  { city: 'São Paulo', country: 'BR', region: 'Sudamérica', lat: -23.5505, lon: -46.6333 },
  { city: 'Ciudad de México', country: 'MX', region: 'Norteamérica', lat: 19.4326, lon: -99.1332 },
  { city: 'Toronto', country: 'CA', region: 'Norteamérica', lat: 43.6532, lon: -79.3832 },
  { city: 'Nueva York', country: 'US', region: 'Norteamérica', lat: 40.7128, lon: -74.006 },
  { city: 'Londres', country: 'GB', region: 'Europa', lat: 51.5072, lon: -0.1276 },
  { city: 'Fráncfort', country: 'DE', region: 'Europa', lat: 50.1109, lon: 8.6821 },
  { city: 'Nairobi', country: 'KE', region: 'África', lat: -1.2921, lon: 36.8219 },
  { city: 'Johannesburgo', country: 'ZA', region: 'África', lat: -26.2041, lon: 28.0473 },
  { city: 'Dubái', country: 'AE', region: 'Asia occidental', lat: 25.2048, lon: 55.2708 },
  { city: 'Mumbai', country: 'IN', region: 'Asia meridional', lat: 19.076, lon: 72.8777 },
  { city: 'Singapur', country: 'SG', region: 'Sudeste asiático', lat: 1.3521, lon: 103.8198 },
  { city: 'Seúl', country: 'KR', region: 'Asia oriental', lat: 37.5665, lon: 126.978 },
  { city: 'Tokio', country: 'JP', region: 'Asia oriental', lat: 35.6762, lon: 139.6503 },
  { city: 'Sídney', country: 'AU', region: 'Oceanía', lat: -33.8688, lon: 151.2093 },
]);

export const EVENT_TYPES = Object.freeze([
  'Patrón anómalo',
  'Sondeo ficticio',
  'Pico de solicitudes',
  'Tráfico sintético',
  'Actividad automatizada',
]);

function safeUnitRandom(random) {
  const value = Number(random());
  if (!Number.isFinite(value)) return 0;
  return Math.min(0.999999999, Math.max(0, value));
}

export function advanceCounter(state, elapsedMs, rate, total = SIMULATION_TOTAL) {
  const safeTotal = Number.isFinite(total) ? Math.max(0, Math.floor(total)) : SIMULATION_TOTAL;
  const completed = Math.min(safeTotal, Math.max(0, Math.floor(Number(state?.completed) || 0)));
  const fractional = Number.isFinite(state?.fractional)
    ? Math.min(0.999999999, Math.max(0, state.fractional))
    : 0;

  if (completed >= safeTotal) return { completed: safeTotal, fractional: 0 };
  if (!Number.isFinite(elapsedMs) || elapsedMs <= 0 || !Number.isFinite(rate) || rate <= 0) {
    return { completed, fractional };
  }

  const exactEvents = fractional + (elapsedMs * rate) / 1000;
  const increment = Math.floor(exactEvents);
  const nextCompleted = Math.min(safeTotal, completed + increment);
  return {
    completed: nextCompleted,
    fractional: nextCompleted >= safeTotal ? 0 : exactEvents - increment,
  };
}

export function createSyntheticEvent(random = Math.random) {
  const sourceIndex = Math.floor(safeUnitRandom(random) * LOCATIONS.length);
  const offset = 1 + Math.floor(safeUnitRandom(random) * (LOCATIONS.length - 1));
  const typeIndex = Math.floor(safeUnitRandom(random) * EVENT_TYPES.length);
  const idPart = Math.floor(safeUnitRandom(random) * 0xffffff)
    .toString(16)
    .padStart(6, '0')
    .toUpperCase();

  return Object.freeze({
    id: `SIM-${idPart}`,
    source: LOCATIONS[sourceIndex],
    target: LOCATIONS[(sourceIndex + offset) % LOCATIONS.length],
    type: EVENT_TYPES[typeIndex],
    synthetic: true,
    createdAt: Date.now(),
  });
}
