const RAD = Math.PI / 180;

const CONTINENTS = [
  [
    [-168, 70], [-150, 61], [-138, 57], [-130, 49], [-124, 42], [-117, 32], [-108, 29], [-104, 22],
    [-97, 18], [-90, 20], [-86, 16], [-82, 9], [-77, 8], [-80, 22], [-92, 28], [-96, 39],
    [-105, 46], [-118, 50], [-125, 59], [-143, 62], [-155, 68],
  ],
  [
    [-81, 12], [-72, 10], [-65, 6], [-58, 5], [-51, -2], [-47, -13], [-42, -22],
    [-49, -30], [-54, -39], [-62, -50], [-69, -55], [-75, -43], [-77, -28], [-80, -9],
  ],
  [
    [-11, 71], [5, 71], [19, 65], [30, 60], [39, 53], [28, 47], [35, 40], [26, 36],
    [17, 37], [9, 44], [0, 44], [-8, 51], [-12, 59],
  ],
  [
    [-18, 35], [-5, 37], [11, 35], [25, 32], [34, 22], [43, 11], [50, 2], [42, -11],
    [37, -22], [29, -34], [18, -35], [12, -25], [8, -8], [1, 5], [-10, 8], [-16, 20],
  ],
  [
    [31, 59], [43, 68], [65, 72], [91, 70], [112, 66], [137, 58], [160, 61], [179, 51],
    [163, 43], [147, 39], [137, 31], [121, 25], [112, 16], [99, 8], [88, 21], [76, 8],
    [62, 25], [51, 31], [40, 42],
  ],
  [
    [112, -11], [129, -10], [145, -15], [154, -27], [149, -39], [134, -43], [119, -34], [113, -23],
  ],
  [
    [46, -13], [50, -17], [49, -25], [44, -26], [41, -17],
  ],
];

function vectorFromLatLon(lat, lon) {
  const latitude = lat * RAD;
  const longitude = lon * RAD;
  return {
    x: Math.cos(latitude) * Math.sin(longitude),
    y: Math.sin(latitude),
    z: Math.cos(latitude) * Math.cos(longitude),
  };
}

function project(lat, lon, rotation, tilt, centerX, centerY, radius, lift = 1) {
  const latitude = lat * RAD;
  const longitude = lon * RAD - rotation;
  const cosLatitude = Math.cos(latitude);
  const sinLatitude = Math.sin(latitude);
  const cosLongitude = Math.cos(longitude);
  const sinLongitude = Math.sin(longitude);
  const cosTilt = Math.cos(tilt);
  const sinTilt = Math.sin(tilt);
  const x = cosLatitude * sinLongitude;
  const y = cosTilt * sinLatitude - sinTilt * cosLatitude * cosLongitude;
  const z = sinTilt * sinLatitude + cosTilt * cosLatitude * cosLongitude;
  return {
    x: centerX + x * radius * lift,
    y: centerY - y * radius * lift,
    z,
  };
}

function drawSegmentedLine(ctx, points, style, width, blur = 0) {
  ctx.beginPath();
  let open = false;
  for (const point of points) {
    if (point && point.z > 0.015) {
      if (!open) {
        ctx.moveTo(point.x, point.y);
        open = true;
      } else {
        ctx.lineTo(point.x, point.y);
      }
    } else {
      open = false;
    }
  }
  ctx.strokeStyle = style;
  ctx.lineWidth = width;
  ctx.shadowBlur = blur;
  ctx.shadowColor = style;
  ctx.stroke();
  ctx.shadowBlur = 0;
}

function drawGrid(ctx, centerX, centerY, radius, rotation, tilt) {
  for (let latitude = -75; latitude <= 75; latitude += 25) {
    const points = [];
    for (let longitude = -180; longitude <= 180; longitude += 4) {
      points.push(project(latitude, longitude, rotation, tilt, centerX, centerY, radius));
    }
    drawSegmentedLine(ctx, points, 'rgba(84, 180, 205, 0.17)', 0.75);
  }

  for (let longitude = -180; longitude < 180; longitude += 20) {
    const points = [];
    for (let latitude = -88; latitude <= 88; latitude += 3) {
      points.push(project(latitude, longitude, rotation, tilt, centerX, centerY, radius));
    }
    drawSegmentedLine(ctx, points, 'rgba(84, 180, 205, 0.14)', 0.7);
  }
}

function drawContinents(ctx, centerX, centerY, radius, rotation, tilt) {
  for (const polygon of CONTINENTS) {
    const projected = polygon.map(([longitude, latitude]) =>
      project(latitude, longitude, rotation, tilt, centerX, centerY, radius * 0.995),
    );
    ctx.beginPath();
    let open = false;
    for (const point of projected) {
      if (point.z > 0.015) {
        if (!open) {
          ctx.moveTo(point.x, point.y);
          open = true;
        } else {
          ctx.lineTo(point.x, point.y);
        }
      } else {
        open = false;
      }
    }
    ctx.strokeStyle = 'rgba(89, 211, 197, 0.66)';
    ctx.lineWidth = 1.2;
    ctx.shadowColor = 'rgba(39, 220, 192, 0.3)';
    ctx.shadowBlur = 5;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }
}

function greatCirclePoints(source, target, rotation, tilt, centerX, centerY, radius, progress) {
  const a = vectorFromLatLon(source.lat, source.lon);
  const b = vectorFromLatLon(target.lat, target.lon);
  const dot = Math.min(1, Math.max(-1, a.x * b.x + a.y * b.y + a.z * b.z));
  const omega = Math.acos(dot);
  const sinOmega = Math.sin(omega);
  const points = [];

  for (let index = 0; index <= 38; index += 1) {
    const t = index / 38;
    let x;
    let y;
    let z;
    if (omega < 0.0001 || Math.abs(sinOmega) < 0.0001) {
      x = a.x + (b.x - a.x) * t;
      y = a.y + (b.y - a.y) * t;
      z = a.z + (b.z - a.z) * t;
    } else {
      const first = Math.sin((1 - t) * omega) / sinOmega;
      const second = Math.sin(t * omega) / sinOmega;
      x = first * a.x + second * b.x;
      y = first * a.y + second * b.y;
      z = first * a.z + second * b.z;
    }
    const length = Math.hypot(x, y, z) || 1;
    x /= length;
    y /= length;
    z /= length;
    const latitude = Math.asin(Math.min(1, Math.max(-1, y))) / RAD;
    const longitude = Math.atan2(x, z) / RAD;
    const altitude = 1 + 0.15 * Math.sin(Math.PI * t);
    const point = project(latitude, longitude, rotation, tilt, centerX, centerY, radius, altitude);
    points.push(point);
  }
  return points;
}

function drawRoutes(ctx, arcs, centerX, centerY, radius, rotation, tilt, now) {
  for (let index = 0; index < arcs.length; index += 1) {
    const arc = arcs[index];
    const points = greatCirclePoints(arc.source, arc.target, rotation, tilt, centerX, centerY, radius, 0);
    const color = index % 3 === 0 ? 'rgba(255, 177, 91, 0.76)' : 'rgba(67, 225, 213, 0.76)';
    drawSegmentedLine(ctx, points, color, 1.25, 8);

    const phase = ((now * 0.00016) + (arc.phase || 0)) % 1;
    const head = points[Math.min(points.length - 1, Math.floor(phase * (points.length - 1)))];
    if (head && head.z > 0) {
      ctx.beginPath();
      ctx.arc(head.x, head.y, 2.6, 0, Math.PI * 2);
      ctx.fillStyle = '#eaffff';
      ctx.shadowColor = color;
      ctx.shadowBlur = 12;
      ctx.fill();
      ctx.shadowBlur = 0;
    }

    const endpoints = [
      project(arc.source.lat, arc.source.lon, rotation, tilt, centerX, centerY, radius),
      project(arc.target.lat, arc.target.lon, rotation, tilt, centerX, centerY, radius),
    ];
    for (const endpoint of endpoints) {
      if (endpoint.z > 0) {
        ctx.beginPath();
        ctx.arc(endpoint.x, endpoint.y, 2.1, 0, Math.PI * 2);
        ctx.fillStyle = '#affff4';
        ctx.fill();
      }
    }
  }
}

export function drawGlobe(canvas, options = {}) {
  if (!canvas) return;
  const bounds = canvas.getBoundingClientRect();
  const width = Math.max(1, bounds.width || 640);
  const height = Math.max(1, bounds.height || 420);
  const pixelRatio = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
  const pixelWidth = Math.round(width * pixelRatio);
  const pixelHeight = Math.round(height * pixelRatio);

  if (canvas.width !== pixelWidth || canvas.height !== pixelHeight) {
    canvas.width = pixelWidth;
    canvas.height = pixelHeight;
  }

  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  ctx.setTransform(pixelRatio, 0, 0, pixelRatio, 0, 0);
  ctx.clearRect(0, 0, width, height);

  const centerX = width * 0.5;
  const centerY = height * 0.51;
  const radius = Math.max(70, Math.min(width * 0.39, height * 0.43));
  const rotation = Number(options.rotation) || 0;
  const tilt = Number.isFinite(options.tilt) ? options.tilt : 0.08;
  const now = Number(options.now) || 0;

  const atmosphere = ctx.createRadialGradient(centerX, centerY, radius * 0.88, centerX, centerY, radius * 1.18);
  atmosphere.addColorStop(0, 'rgba(40, 214, 201, 0)');
  atmosphere.addColorStop(0.72, 'rgba(40, 214, 201, 0.06)');
  atmosphere.addColorStop(1, 'rgba(40, 214, 201, 0)');
  ctx.fillStyle = atmosphere;
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius * 1.18, 0, Math.PI * 2);
  ctx.fill();

  ctx.save();
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
  ctx.clip();

  const ocean = ctx.createRadialGradient(centerX - radius * 0.35, centerY - radius * 0.45, radius * 0.06, centerX, centerY, radius * 1.1);
  ocean.addColorStop(0, '#123a4d');
  ocean.addColorStop(0.55, '#0b2639');
  ocean.addColorStop(1, '#06121f');
  ctx.fillStyle = ocean;
  ctx.fillRect(centerX - radius, centerY - radius, radius * 2, radius * 2);

  drawGrid(ctx, centerX, centerY, radius, rotation, tilt);
  drawContinents(ctx, centerX, centerY, radius, rotation, tilt);

  const glow = ctx.createRadialGradient(centerX - radius * 0.38, centerY - radius * 0.44, radius * 0.03, centerX, centerY, radius);
  glow.addColorStop(0, 'rgba(152, 255, 228, 0.10)');
  glow.addColorStop(0.6, 'rgba(65, 174, 196, 0.025)');
  glow.addColorStop(1, 'rgba(1, 6, 14, 0.48)');
  ctx.fillStyle = glow;
  ctx.fillRect(centerX - radius, centerY - radius, radius * 2, radius * 2);
  ctx.restore();

  drawRoutes(ctx, Array.isArray(options.arcs) ? options.arcs : [], centerX, centerY, radius, rotation, tilt, now);

  ctx.beginPath();
  ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
  ctx.strokeStyle = 'rgba(112, 245, 226, 0.42)';
  ctx.lineWidth = 1.1;
  ctx.shadowColor = 'rgba(64, 225, 205, 0.42)';
  ctx.shadowBlur = 13;
  ctx.stroke();
  ctx.shadowBlur = 0;

  const reticle = project(0, 0, rotation, tilt, centerX, centerY, radius);
  if (reticle.z > 0) {
    ctx.beginPath();
    ctx.arc(reticle.x, reticle.y, 3.4, 0, Math.PI * 2);
    ctx.strokeStyle = 'rgba(147, 255, 230, 0.66)';
    ctx.lineWidth = 1;
    ctx.stroke();
  }
}
