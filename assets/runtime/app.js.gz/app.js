import {
  DEFAULT_RATE,
  EVENT_TYPES,
  LOCATIONS,
  SIMULATION_TOTAL,
  advanceCounter,
  createSyntheticEvent,
} from './simulation.js';
import { drawGlobe } from './globe.js';

const $ = (id) => document.getElementById(id);
const numberFormat = new Intl.NumberFormat('es-AR');
const regionNames = [...new Set(LOCATIONS.map((location) => location.region))];
const typeColors = ['type-cyan', 'type-blue', 'type-amber', 'type-green', 'type-violet'];
const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ?? false;

const elements = {
  canvas: $('globeCanvas'),
  eventsCount: $('eventsCount'),
  rateCount: $('rateCount'),
  regionsCount: $('regionsCount'),
  elapsedCount: $('elapsedCount'),
  sessionState: $('sessionState'),
  progressPercent: $('progressPercent'),
  progressFill: $('progressFill'),
  runState: $('runState'),
  controlStatus: $('controlStatus'),
  controlSubstatus: $('controlSubstatus'),
  controlPulse: $('controlPulse'),
  startBtn: $('startBtn'),
  pauseBtn: $('pauseBtn'),
  resetBtn: $('resetBtn'),
  speedSelect: $('speedSelect'),
  speedLabel: $('speedLabel'),
  mapState: $('mapState'),
  mapLive: document.querySelector('.map-live'),
  routeSummary: $('routeSummary'),
  feedCount: $('feedCount'),
  eventFeed: $('eventFeed'),
  regionList: $('regionList'),
  typeGrid: $('typeGrid'),
  installBtn: $('installBtn'),
  toast: $('toast'),
};

const state = {
  running: false,
  completed: 0,
  fractional: 0,
  elapsedMs: 0,
  rate: DEFAULT_RATE,
  rotation: 0.34,
  tilt: 0.08,
  lastFrame: 0,
  lastUiUpdate: 0,
  sampleElapsed: 0,
  events: [],
  regionCounts: Object.fromEntries(regionNames.map((name) => [name, 0])),
  typeCounts: Object.fromEntries(EVENT_TYPES.map((name) => [name, 0])),
  sessionState: 'ready',
};

let installPrompt = null;
let toastTimer = null;
let dragState = null;
let renderedStatus = null;

function formatNumber(value) {
  return numberFormat.format(Math.max(0, Math.floor(value)));
}

function formatElapsed(milliseconds) {
  const totalSeconds = Math.floor(milliseconds / 1000);
  const seconds = String(totalSeconds % 60).padStart(2, '0');
  const minutes = String(Math.floor(totalSeconds / 60) % 60).padStart(2, '0');
  const hours = Math.floor(totalSeconds / 3600);
  return hours > 0 ? `${String(hours).padStart(2, '0')}:${minutes}:${seconds}` : `${minutes}:${seconds}`;
}

function formatRate(value) {
  return `${formatNumber(value)} /s`;
}

function showToast(message) {
  if (!elements.toast) return;
  elements.toast.textContent = message;
  elements.toast.classList.add('visible');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => elements.toast.classList.remove('visible'), 2800);
}

function updateStatus() {
  if (renderedStatus === state.sessionState) return;
  renderedStatus = state.sessionState;
  const statusMap = {
    ready: { label: 'LISTA', control: 'En espera', sub: 'Listo para iniciar el escenario', session: 'Esperando inicio', map: 'EN ESPERA', className: '' },
    running: { label: 'EN CURSO', control: 'Simulación activa', sub: 'Generando eventos ficticios localmente', session: 'Simulación en curso', map: 'EN CURSO', className: 'active' },
    paused: { label: 'PAUSADA', control: 'Simulación pausada', sub: 'El escenario está detenido', session: 'Simulación pausada', map: 'PAUSADA', className: 'paused' },
    complete: { label: 'COMPLETA', control: 'Escenario finalizado', sub: 'Se alcanzó el volumen simulado', session: 'Escenario completado', map: 'COMPLETA', className: 'active' },
  };
  const current = statusMap[state.sessionState];
  elements.runState.textContent = current.label;
  elements.controlStatus.textContent = current.control;
  elements.controlSubstatus.textContent = current.sub;
  elements.sessionState.textContent = current.session;
  elements.mapState.textContent = current.map;
  elements.mapLive.classList.toggle('active', state.sessionState === 'running' || state.sessionState === 'complete');
  elements.controlPulse.className = `control-pulse ${current.className}`.trim();
  elements.startBtn.disabled = state.running || state.completed >= SIMULATION_TOTAL;
  elements.pauseBtn.disabled = !state.running;
  elements.startBtn.innerHTML = state.completed > 0 && state.completed < SIMULATION_TOTAL
    ? '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6.8 4.9v10.2L15 10 6.8 4.9Z" fill="currentColor"/></svg> Continuar simulación'
    : '<svg viewBox="0 0 20 20" aria-hidden="true"><path d="M6.8 4.9v10.2L15 10 6.8 4.9Z" fill="currentColor"/></svg> Iniciar simulación';
}

function renderRegionList() {
  const ordered = [...regionNames].sort((a, b) => state.regionCounts[b] - state.regionCounts[a]);
  const visible = ordered.slice(0, 6);
  const maxCount = Math.max(1, ...visible.map((name) => state.regionCounts[name]));
  const fragment = document.createDocumentFragment();

  for (const name of visible) {
    const row = document.createElement('div');
    row.className = 'region-row';
    const label = document.createElement('span');
    label.textContent = name;
    const track = document.createElement('div');
    track.className = 'region-track';
    const fill = document.createElement('i');
    fill.style.width = `${(state.regionCounts[name] / maxCount) * (state.regionCounts[name] ? 100 : 0)}%`;
    track.append(fill);
    const count = document.createElement('b');
    count.textContent = formatNumber(state.regionCounts[name]);
    row.append(label, track, count);
    fragment.append(row);
  }
  elements.regionList.replaceChildren(fragment);
}

function renderTypeGrid() {
  const fragment = document.createDocumentFragment();
  EVENT_TYPES.forEach((name, index) => {
    const row = document.createElement('div');
    row.className = 'type-item';
    const color = document.createElement('span');
    color.className = `type-color ${typeColors[index]}`;
    const label = document.createElement('span');
    label.textContent = name;
    const count = document.createElement('b');
    count.textContent = formatNumber(state.typeCounts[name]);
    row.append(color, label, count);
    fragment.append(row);
  });
  elements.typeGrid.replaceChildren(fragment);
}

function renderFeed() {
  if (state.events.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'feed-empty';
    const icon = document.createElement('span');
    icon.className = 'empty-icon';
    icon.textContent = '⌁';
    const title = document.createElement('strong');
    title.textContent = 'Sin actividad todavía';
    const description = document.createElement('small');
    description.textContent = 'Iniciá la simulación para generar muestras ficticias.';
    empty.append(icon, title, description);
    elements.eventFeed.replaceChildren(empty);
    elements.feedCount.textContent = '00';
    elements.routeSummary.textContent = 'SIN RUTAS ACTIVAS';
    return;
  }

  const fragment = document.createDocumentFragment();
  for (const event of state.events.slice(0, 8)) {
    const item = document.createElement('article');
    item.className = 'event-item';
    const top = document.createElement('div');
    top.className = 'event-top';
    const id = document.createElement('span');
    id.className = 'event-id';
    id.textContent = event.id;
    const badge = document.createElement('span');
    badge.className = 'event-badge';
    badge.textContent = event.type.toUpperCase();
    top.append(id, badge);

    const route = document.createElement('div');
    route.className = 'event-route';
    const source = document.createElement('span');
    source.textContent = event.source.city;
    const arrow = document.createElement('span');
    arrow.textContent = '→';
    const target = document.createElement('span');
    target.textContent = event.target.city;
    route.append(source, arrow, target);

    const meta = document.createElement('div');
    meta.className = 'event-meta';
    const location = document.createElement('span');
    location.textContent = `${event.source.country} / ${event.target.country}`;
    const time = document.createElement('span');
    time.textContent = event.timeLabel;
    meta.append(location, time);
    item.append(top, route, meta);
    fragment.append(item);
  }
  elements.eventFeed.replaceChildren(fragment);
  elements.feedCount.textContent = String(state.events.length).padStart(2, '0');
  const latest = state.events[0];
  elements.routeSummary.textContent = `${latest.source.city.toUpperCase()}  →  ${latest.target.city.toUpperCase()}`;
}

function updateDashboard(now = performance.now()) {
  elements.eventsCount.textContent = formatNumber(state.completed);
  elements.rateCount.innerHTML = `${formatNumber(state.running ? state.rate : 0)} <small>/s</small>`;
  elements.regionsCount.innerHTML = `${regionNames.filter((name) => state.regionCounts[name] > 0).length} <small>/ 9</small>`;
  elements.elapsedCount.textContent = formatElapsed(state.elapsedMs);
  const percentage = (state.completed / SIMULATION_TOTAL) * 100;
  elements.progressPercent.textContent = `${percentage.toLocaleString('es-AR', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;
  elements.progressFill.style.width = `${percentage}%`;
  elements.speedLabel.textContent = formatRate(state.rate);
  updateStatus();
  if (now - state.lastUiUpdate > 900) {
    renderRegionList();
    renderTypeGrid();
    state.lastUiUpdate = now;
  }
}

function addSyntheticSample(now) {
  const generated = createSyntheticEvent();
  const event = {
    ...generated,
    phase: Math.random(),
    createdAt: now,
    timeLabel: formatElapsed(state.elapsedMs),
  };
  state.events.unshift(event);
  state.events = state.events.slice(0, 12);
  state.regionCounts[event.target.region] += 1;
  state.typeCounts[event.type] += 1;
  renderFeed();
}

function startSimulation() {
  if (state.completed >= SIMULATION_TOTAL || state.running) return;
  state.running = true;
  state.sessionState = 'running';
  updateDashboard();
  showToast('Simulación iniciada: todos los eventos son ficticios.');
}

function pauseSimulation() {
  if (!state.running) return;
  state.running = false;
  state.sessionState = 'paused';
  updateDashboard();
  showToast('Simulación pausada. El progreso se conserva.');
}

function resetSimulation() {
  state.running = false;
  state.completed = 0;
  state.fractional = 0;
  state.elapsedMs = 0;
  state.sampleElapsed = 0;
  state.events = [];
  state.regionCounts = Object.fromEntries(regionNames.map((name) => [name, 0]));
  state.typeCounts = Object.fromEntries(EVENT_TYPES.map((name) => [name, 0]));
  state.sessionState = 'ready';
  renderedStatus = null;
  state.lastUiUpdate = 0;
  renderFeed();
  updateDashboard();
  showToast('Escenario reiniciado.');
}

function animationFrame(now) {
  const elapsed = state.lastFrame ? Math.min(100, Math.max(0, now - state.lastFrame)) : 0;
  state.lastFrame = now;

  if (state.running) {
    state.elapsedMs += elapsed;
    const next = advanceCounter(
      { completed: state.completed, fractional: state.fractional },
      elapsed,
      state.rate,
      SIMULATION_TOTAL,
    );
    state.completed = next.completed;
    state.fractional = next.fractional;
    state.sampleElapsed += elapsed;

    if (state.sampleElapsed >= 430 && state.completed < SIMULATION_TOTAL) {
      state.sampleElapsed %= 430;
      addSyntheticSample(now);
    }

    if (state.completed >= SIMULATION_TOTAL) {
      state.running = false;
      state.sessionState = 'complete';
      showToast('Escenario completado: 3.000.000 de eventos ficticios.');
    }
  } else if (!reducedMotion) {
    state.rotation += elapsed * 0.000006;
  }

  updateDashboard(now);
  drawGlobe(elements.canvas, {
    rotation: state.rotation,
    tilt: state.tilt,
    arcs: state.events,
    now,
  });
  window.requestAnimationFrame(animationFrame);
}

function handleCanvasPointerDown(event) {
  dragState = { x: event.clientX, y: event.clientY };
  elements.canvas.setPointerCapture?.(event.pointerId);
}

function handleCanvasPointerMove(event) {
  if (!dragState) return;
  const dx = event.clientX - dragState.x;
  const dy = event.clientY - dragState.y;
  dragState = { x: event.clientX, y: event.clientY };
  state.rotation += dx * 0.006;
  state.tilt = Math.max(-0.55, Math.min(0.55, state.tilt + dy * 0.003));
}

function handleCanvasPointerUp() {
  dragState = null;
}

function setupInstallPrompt() {
  window.addEventListener('beforeinstallprompt', (event) => {
    event.preventDefault();
    installPrompt = event;
    elements.installBtn.hidden = false;
  });

  elements.installBtn.addEventListener('click', async () => {
    if (!installPrompt) return;
    installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice?.outcome === 'accepted') showToast('Instalación aceptada por el navegador.');
    installPrompt = null;
    elements.installBtn.hidden = true;
  });

  window.addEventListener('appinstalled', () => {
    elements.installBtn.hidden = true;
    showToast('NEXUS quedó instalado en este dispositivo.');
  });
}

function setupServiceWorker() {
  if (!('serviceWorker' in navigator) || location.protocol === 'file:') return;
  navigator.serviceWorker.register('./sw.js', { scope: './' }).catch(() => {
    showToast('El modo offline no está disponible en este navegador.');
  });
}

function setupControls() {
  elements.startBtn.addEventListener('click', startSimulation);
  elements.pauseBtn.addEventListener('click', pauseSimulation);
  elements.resetBtn.addEventListener('click', resetSimulation);
  elements.speedSelect.addEventListener('change', () => {
    const selected = Number(elements.speedSelect.value);
    if (Number.isFinite(selected) && selected > 0) {
      state.rate = selected;
      elements.speedLabel.textContent = formatRate(state.rate);
      updateDashboard();
    }
  });
  elements.canvas.addEventListener('pointerdown', handleCanvasPointerDown);
  elements.canvas.addEventListener('pointermove', handleCanvasPointerMove);
  elements.canvas.addEventListener('pointerup', handleCanvasPointerUp);
  elements.canvas.addEventListener('pointercancel', handleCanvasPointerUp);
  elements.canvas.addEventListener('lostpointercapture', handleCanvasPointerUp);
  window.addEventListener('resize', () => drawGlobe(elements.canvas, { rotation: state.rotation, tilt: state.tilt, arcs: state.events, now: performance.now() }));
}

setupControls();
setupInstallPrompt();
setupServiceWorker();
renderFeed();
updateDashboard();
window.requestAnimationFrame(animationFrame);
